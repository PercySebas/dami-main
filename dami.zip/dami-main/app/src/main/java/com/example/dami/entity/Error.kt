package com.example.dami.entity

class Error (val codigo: String, val mensaje: String)